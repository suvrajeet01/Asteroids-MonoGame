﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Asteroids
{
	class Asteroid
	{
		public Texture2D AsteroidTexture;
		public Vector2 Position;
		public Vector2 Velocity;
		public float Speed;
		public float Rotation;
		public Vector2 Origin;
		public float MaxX;
		public float MaxY;
		public int Width
		{
			get { return AsteroidTexture.Width; }
		}

		public int Height
		{
			get { return AsteroidTexture.Height; }
		}

		public Asteroid(Texture2D texture, Vector2 position, Vector2 Max)
		{
			AsteroidTexture = texture;
			Position = position;
			Origin = new Vector2(Width / 2, Height/2);
			Speed = 20F;
			Velocity.X = ((float)Math.Cos(Rotation * Math.PI / 180) * Speed);
			Velocity.Y = ((float)Math.Sin(Rotation * Math.PI / 180) * Speed);
			MaxX = Max.X;
			MaxY = Max.Y;
		}

		public void Update(GameTime gameTime)
		{
			Rotation += 1;
			float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
			Position += Velocity * deltaTime;
			if (Position.X > MaxX)
			{
				Position.X = 0;
			}
			if (Position.X < 0)
			{
				Position.X = MaxX;
			}
			if (Position.Y > MaxY)
			{
				Position.Y = 0;
			}
			if (Position.Y < 0)
			{
				Position.Y = MaxY;
			}
		}

		public void Draw(SpriteBatch spriteBatch)
		{
			spriteBatch.Draw(AsteroidTexture, Position, null, Color.White, (float)((Rotation + 90) * Math.PI / 180), Origin, 0.2f, SpriteEffects.None, 0f);
		}
	}
}
